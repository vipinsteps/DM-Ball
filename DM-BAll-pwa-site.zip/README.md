# Ceratizit Ball Nose Calculator (PWA)

This is a responsive Progressive Web App (PWA) for Ceratizit tool calculations.

## Usage
Upload the contents of this folder to a GitHub repo. Then enable GitHub Pages under:
Settings > Pages > Source = main > root

GitHub will provide a live URL to access and install the app.

## Files
- `index.html` — The web app UI
- `manifest.json` — Mobile PWA metadata
- `service-worker.js` — Enables offline access
